﻿namespace TPV_Software
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            label6 = new Label();
            textBox2 = new TextBox();
            textBox5 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            button27 = new Button();
            panel3 = new Panel();
            textBox1 = new TextBox();
            button26 = new Button();
            button25 = new Button();
            button24 = new Button();
            button23 = new Button();
            button22 = new Button();
            button21 = new Button();
            button20 = new Button();
            button19 = new Button();
            button18 = new Button();
            button17 = new Button();
            button16 = new Button();
            button15 = new Button();
            button14 = new Button();
            button13 = new Button();
            button12 = new Button();
            button11 = new Button();
            button10 = new Button();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            monthCalendar1 = new MonthCalendar();
            panel2 = new Panel();
            dataGridView1 = new DataGridView();
            button2 = new Button();
            panel1 = new Panel();
            button6 = new Button();
            button4 = new Button();
            button1 = new Button();
            button3 = new Button();
            label4 = new Label();
            button5 = new Button();
            label3 = new Label();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.System;
            label5.Font = new Font("Segoe UI", 8F);
            label5.Location = new Point(483, 455);
            label5.Name = "label5";
            label5.Size = new Size(54, 13);
            label5.TabIndex = 45;
            label5.Text = "Cantidad";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.FlatStyle = FlatStyle.System;
            label6.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            label6.Location = new Point(483, 390);
            label6.Name = "label6";
            label6.Size = new Size(49, 13);
            label6.TabIndex = 44;
            label6.Text = "Nombre";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(483, 473);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(257, 23);
            textBox2.TabIndex = 43;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(483, 417);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(257, 23);
            textBox5.TabIndex = 42;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.System;
            label2.Font = new Font("Segoe UI", 8F);
            label2.Location = new Point(194, 455);
            label2.Name = "label2";
            label2.Size = new Size(38, 13);
            label2.TabIndex = 41;
            label2.Text = "Precio";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.System;
            label1.Font = new Font("Segoe UI Semibold", 8F, FontStyle.Bold);
            label1.Location = new Point(194, 390);
            label1.Name = "label1";
            label1.Size = new Size(17, 13);
            label1.TabIndex = 40;
            label1.Text = "Id";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(194, 473);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(257, 23);
            textBox3.TabIndex = 39;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(194, 417);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(257, 23);
            textBox4.TabIndex = 38;
            // 
            // button27
            // 
            button27.BackColor = Color.Black;
            button27.BackgroundImageLayout = ImageLayout.Center;
            button27.FlatAppearance.BorderColor = SystemColors.ControlLight;
            button27.FlatAppearance.BorderSize = 0;
            button27.FlatStyle = FlatStyle.Flat;
            button27.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button27.ForeColor = SystemColors.ControlLightLight;
            button27.Location = new Point(194, 514);
            button27.Name = "button27";
            button27.Size = new Size(546, 32);
            button27.TabIndex = 37;
            button27.Text = "Modificar";
            button27.UseVisualStyleBackColor = false;
            button27.Click += button27_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(textBox1);
            panel3.Controls.Add(button26);
            panel3.Controls.Add(button25);
            panel3.Controls.Add(button24);
            panel3.Controls.Add(button23);
            panel3.Controls.Add(button22);
            panel3.Controls.Add(button21);
            panel3.Controls.Add(button20);
            panel3.Controls.Add(button19);
            panel3.Controls.Add(button18);
            panel3.Controls.Add(button17);
            panel3.Controls.Add(button16);
            panel3.Controls.Add(button15);
            panel3.Controls.Add(button14);
            panel3.Controls.Add(button13);
            panel3.Controls.Add(button12);
            panel3.Controls.Add(button11);
            panel3.Controls.Add(button10);
            panel3.Controls.Add(button9);
            panel3.Controls.Add(button8);
            panel3.Controls.Add(button7);
            panel3.Location = new Point(1011, 251);
            panel3.Name = "panel3";
            panel3.Size = new Size(192, 246);
            panel3.TabIndex = 36;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(0, 34);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(192, 23);
            textBox1.TabIndex = 35;
            // 
            // button26
            // 
            button26.Location = new Point(150, 63);
            button26.Name = "button26";
            button26.Size = new Size(42, 31);
            button26.TabIndex = 34;
            button26.Text = "1";
            button26.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            button25.Location = new Point(102, 63);
            button25.Name = "button25";
            button25.Size = new Size(42, 31);
            button25.TabIndex = 33;
            button25.Text = "C";
            button25.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            button24.Location = new Point(54, 63);
            button24.Name = "button24";
            button24.Size = new Size(42, 31);
            button24.TabIndex = 32;
            button24.Text = "CE";
            button24.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            button23.Location = new Point(0, 63);
            button23.Name = "button23";
            button23.Size = new Size(42, 31);
            button23.TabIndex = 31;
            button23.Text = "%";
            button23.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            button22.Location = new Point(150, 100);
            button22.Name = "button22";
            button22.Size = new Size(42, 31);
            button22.TabIndex = 30;
            button22.Text = "/";
            button22.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            button21.Location = new Point(102, 100);
            button21.Name = "button21";
            button21.Size = new Size(42, 31);
            button21.TabIndex = 29;
            button21.Text = "9";
            button21.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            button20.Location = new Point(54, 100);
            button20.Name = "button20";
            button20.Size = new Size(42, 31);
            button20.TabIndex = 28;
            button20.Text = "8";
            button20.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            button19.Location = new Point(0, 100);
            button19.Name = "button19";
            button19.Size = new Size(42, 31);
            button19.TabIndex = 27;
            button19.Text = "7";
            button19.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            button18.Location = new Point(150, 137);
            button18.Name = "button18";
            button18.Size = new Size(42, 31);
            button18.TabIndex = 26;
            button18.Text = "x";
            button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            button17.Location = new Point(102, 137);
            button17.Name = "button17";
            button17.Size = new Size(42, 31);
            button17.TabIndex = 25;
            button17.Text = "6";
            button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.Location = new Point(54, 137);
            button16.Name = "button16";
            button16.Size = new Size(42, 31);
            button16.TabIndex = 24;
            button16.Text = "5";
            button16.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            button15.Location = new Point(0, 137);
            button15.Name = "button15";
            button15.Size = new Size(42, 31);
            button15.TabIndex = 23;
            button15.Text = "4";
            button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.Location = new Point(150, 211);
            button14.Name = "button14";
            button14.Size = new Size(42, 31);
            button14.TabIndex = 20;
            button14.Text = "=";
            button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(102, 211);
            button13.Name = "button13";
            button13.Size = new Size(42, 31);
            button13.TabIndex = 20;
            button13.Text = ",";
            button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(0, 211);
            button12.Name = "button12";
            button12.Size = new Size(42, 31);
            button12.TabIndex = 20;
            button12.Text = "add";
            button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(150, 174);
            button11.Name = "button11";
            button11.Size = new Size(42, 31);
            button11.TabIndex = 22;
            button11.Text = "+";
            button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(102, 174);
            button10.Name = "button10";
            button10.Size = new Size(42, 31);
            button10.TabIndex = 21;
            button10.Text = "3";
            button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(54, 174);
            button9.Name = "button9";
            button9.Size = new Size(42, 31);
            button9.TabIndex = 20;
            button9.Text = "2";
            button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(54, 212);
            button8.Name = "button8";
            button8.Size = new Size(42, 31);
            button8.TabIndex = 19;
            button8.Text = "0";
            button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(0, 174);
            button7.Name = "button7";
            button7.Size = new Size(42, 31);
            button7.TabIndex = 0;
            button7.Text = "1";
            button7.UseVisualStyleBackColor = true;
            // 
            // monthCalendar1
            // 
            monthCalendar1.Location = new Point(1011, 89);
            monthCalendar1.Name = "monthCalendar1";
            monthCalendar1.TabIndex = 35;
            monthCalendar1.DateChanged += monthCalendar1_DateChanged_1;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(dataGridView1);
            panel2.Location = new Point(194, 89);
            panel2.Name = "panel2";
            panel2.Size = new Size(805, 282);
            panel2.TabIndex = 34;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ControlLightLight;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(-1, -1);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(805, 282);
            dataGridView1.TabIndex = 0;
            // 
            // button2
            // 
            button2.Location = new Point(1011, 515);
            button2.Name = "button2";
            button2.Size = new Size(89, 31);
            button2.TabIndex = 30;
            button2.Text = "Eliminar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(button3);
            panel1.Location = new Point(15, 89);
            panel1.Name = "panel1";
            panel1.Size = new Size(147, 457);
            panel1.TabIndex = 33;
            // 
            // button6
            // 
            button6.BackColor = Color.Black;
            button6.BackgroundImageLayout = ImageLayout.Center;
            button6.FlatAppearance.BorderColor = SystemColors.ControlLight;
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.ForeColor = SystemColors.ControlLightLight;
            button6.Location = new Point(21, 350);
            button6.Name = "button6";
            button6.Size = new Size(106, 86);
            button6.TabIndex = 16;
            button6.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.Black;
            button4.BackgroundImageLayout = ImageLayout.Center;
            button4.FlatAppearance.BorderColor = SystemColors.ControlLight;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = SystemColors.ControlLightLight;
            button4.Location = new Point(21, 243);
            button4.Name = "button4";
            button4.Size = new Size(106, 86);
            button4.TabIndex = 16;
            button4.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.BackgroundImageLayout = ImageLayout.Center;
            button1.FlatAppearance.BorderColor = SystemColors.ControlLight;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ControlLightLight;
            button1.Location = new Point(21, 21);
            button1.Name = "button1";
            button1.Size = new Size(106, 86);
            button1.TabIndex = 10;
            button1.Text = "Gestion Reservas";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // button3
            // 
            button3.BackColor = Color.Black;
            button3.BackgroundImageLayout = ImageLayout.Center;
            button3.FlatAppearance.BorderColor = SystemColors.ControlLight;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = SystemColors.ControlLightLight;
            button3.Location = new Point(21, 132);
            button3.Name = "button3";
            button3.Size = new Size(106, 86);
            button3.TabIndex = 9;
            button3.Text = "Gestion Pedidos";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click_1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ControlLightLight;
            label4.Font = new Font("Segoe UI", 8F);
            label4.ForeColor = SystemColors.ControlDarkDark;
            label4.Location = new Point(194, 54);
            label4.Name = "label4";
            label4.Size = new Size(284, 13);
            label4.TabIndex = 32;
            label4.Text = "En esta pestaña podra realizar los cambios que quiera";
            // 
            // button5
            // 
            button5.Location = new Point(1124, 515);
            button5.Name = "button5";
            button5.Size = new Size(79, 31);
            button5.TabIndex = 31;
            button5.Text = "Cerrar ";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.System;
            label3.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(194, 17);
            label3.Name = "label3";
            label3.Size = new Size(286, 37);
            label3.TabIndex = 29;
            label3.Text = "Bienvenido de nuevo";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLightLight;
            ClientSize = new Size(1219, 563);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(textBox2);
            Controls.Add(textBox5);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox3);
            Controls.Add(textBox4);
            Controls.Add(button27);
            Controls.Add(panel3);
            Controls.Add(monthCalendar1);
            Controls.Add(panel2);
            Controls.Add(button2);
            Controls.Add(panel1);
            Controls.Add(label4);
            Controls.Add(button5);
            Controls.Add(label3);
            Name = "Form3";
            Text = "Form3";
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private Label label6;
        private TextBox textBox2;
        private TextBox textBox5;
        private Label label2;
        private Label label1;
        private TextBox textBox3;
        private TextBox textBox4;
        private Button button27;
        private Panel panel3;
        private TextBox textBox1;
        private Button button26;
        private Button button25;
        private Button button24;
        private Button button23;
        private Button button22;
        private Button button21;
        private Button button20;
        private Button button19;
        private Button button18;
        private Button button17;
        private Button button16;
        private Button button15;
        private Button button14;
        private Button button13;
        private Button button12;
        private Button button11;
        private Button button10;
        private Button button9;
        private Button button8;
        private Button button7;
        private MonthCalendar monthCalendar1;
        private Panel panel2;
        private Button button2;
        private Panel panel1;
        private Button button6;
        private Button button4;
        private Button button1;
        private Button button3;
        private Label label4;
        private Button button5;
        private Label label3;
        private DataGridView dataGridView1;
    }
}